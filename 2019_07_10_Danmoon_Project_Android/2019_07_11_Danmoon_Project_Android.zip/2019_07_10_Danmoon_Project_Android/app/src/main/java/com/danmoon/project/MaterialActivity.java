package com.danmoon.project;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MaterialActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_material);

        final Material_MaterialFragment materialMaterialFragment = new Material_MaterialFragment();
        final Material_PostFragment materialPostFragment = new Material_PostFragment();

        FragmentManager fragmentManager = getSupportFragmentManager();
        final FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        fragmentTransaction.add(R.id.material_layout, materialMaterialFragment);
        fragmentTransaction.add(R.id.post_layout, materialPostFragment);

        fragmentTransaction.commit();


    }

    public void replaceFragment(Fragment fragment){
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTrasaction = fragmentManager.beginTransaction();
        fragmentTrasaction.setCustomAnimations(R.anim.post_enter_from_bottom, R.anim.post_exit_to_top, R.anim.post_enter_from_bottom, R.anim.post_exit_to_top);
        fragmentTrasaction.addToBackStack(null);
        fragmentTrasaction.commit();

    }
}
