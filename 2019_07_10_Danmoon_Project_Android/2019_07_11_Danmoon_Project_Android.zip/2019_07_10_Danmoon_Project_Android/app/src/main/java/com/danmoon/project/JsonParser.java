package com.danmoon.project;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class JsonParser {

    public MemberDto JsonParserForKakao(String response){
        System.out.println("JsonParser JsonParserForKakao");
        MemberDto memberDto = new MemberDto();
        try {

            if(isJSONValid(response)) {
                System.out.println("response는 JSON형태가 맞음");
                JSONObject jsonObject = new JSONObject(response);
                memberDto.setIdx(jsonObject.getString("idx"));
                memberDto.setEmail(jsonObject.getString("email"));
                memberDto.setNickname(jsonObject.getString("nickname"));
                memberDto.setType(jsonObject.getString("type"));
            } else{
                System.out.println("response는 JSON형태가 아님");
            }
       } catch(JSONException e){
           e.printStackTrace();
       }

        return memberDto;
    }

    public MemberDto JsonParserForLocal(String response){
        System.out.println("JsonParser JsonParserForLocal");
        MemberDto memberDto = new MemberDto();
        try {

            if(isJSONValid(response)) {
                System.out.println("response는 JSON형태가 맞음");
                JSONObject jsonObject = new JSONObject(response);
                memberDto.setIdx(jsonObject.getString("idx"));
                memberDto.setEmail(jsonObject.getString("email"));
                memberDto.setNickname(jsonObject.getString("nickname"));
                memberDto.setType(jsonObject.getString("type"));
            } else{
                System.out.println("response는 JSON형태가 아님");
            }
        } catch(JSONException e){
            e.printStackTrace();
        }

        return memberDto;
    }

    // 서버로 받은 응답이 JSON 형태인지 판별하기위한 메소드
    public boolean isJSONValid(String response) {
        try {
            new JSONObject(response);
        } catch (JSONException ex) {
            // edited, to include @Arthur's comment
            // e.g. in case JSONArray is valid as well...
            try {
                new JSONArray(response);
            } catch (JSONException ex1) {
                return false;
            }
        }
        return true;
    }

}


