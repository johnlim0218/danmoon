package com.danmoon.project;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

import java.util.HashMap;
import java.util.Map;

public class Material_PostFragment extends Fragment {

    static final String insertPostURL = "/danmoon/insertPost";

    Button materialCancelButton;
    Button materialConfirmButton;
    TextView materialText;
    LinearLayout postMenuSwitchLayout;

    String postMaterialStr;
    String postContentStr;

    public static Material_PostFragment newInstance() {
        return new Material_PostFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        materialCancelButton = (Button)getActivity().findViewById(R.id.material_cancel_button);
        materialConfirmButton = (Button)getActivity().findViewById(R.id.material_confirm_button);
        materialText = (TextView)getActivity().findViewById(R.id.material_text);
//        postMenuSwitchLayout = (LinearLayout)getActivity().findViewById(R.id.post_menu_layout);

        postMaterialStr = materialText.getText().toString();

        View view = inflater.inflate(R.layout.material_post_fragment, container, false);
        final ViewGroup postContent = (ViewGroup)view.findViewById(R.id.post_content_view);

        final EditText postContentText = (EditText)view.findViewById(R.id.post_content_text);

        final LinearLayout materialLayout = (LinearLayout)getActivity().findViewById(R.id.material_layout);
        final LinearLayout postLayout = (LinearLayout)getActivity().findViewById(R.id.post_layout);

        postContent.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {

                materialCancelButton.setVisibility(View.VISIBLE);
                materialConfirmButton.setVisibility(View.VISIBLE);
//                postMenuSwitchLayout.setVisibility(View.VISIBLE);
                materialText.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 18);

                materialLayout.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 200));
                postLayout.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));

                materialConfirmButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        postContentStr = postContentText.getText().toString();
                        writingPost(postMaterialStr, postContentStr);
                    }
                });

                return false;
            }
        });

//        postContentText.setOnTouchListener(new View.OnTouchListener() {
//            @Override
//            public boolean onTouch(View view, MotionEvent motionEvent) {
//
//                materialLayout.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 200));
//                postLayout.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));
//
//                return false;
//            }
//        });


        return view;
    }

    public void writingPost(String postMaterialStr, String postContentStr){
        MemberDto memberDto = new MemberDto();
        LoggedInInfoChecker loggedInInfoChecker = new LoggedInInfoChecker(getContext());
        memberDto = loggedInInfoChecker.loggedInInfoReader();

        Map<String, String> postData = new HashMap<>();
        postData.put("mem_idx", memberDto.getIdx());
        postData.put("material", postMaterialStr);
        postData.put("content", postContentStr);


    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        // TODO: Use the ViewModel
    }

}
